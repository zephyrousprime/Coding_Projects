import { ChaosSystem } from './ChaosSystem.js';
import { CallingSystem } from './CallingSystem.js';
const canv = document.getElementsByClassName('canvas_ontainer')[0];
let chaos;
let system;
let currentMode = "simple"; // default mode

window.setup = function() {
  window.createCanvas(1200, 700, WEBGL, canv);
  chaos = new ChaosSystem();
  system = new CallingSystem(chaos); // pass it in
  // Add event listeners for radio buttons
  document.querySelectorAll('input[name="canvas"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      let value = e.target.value;
      if (value === "advance") { currentMode = "advance";
      } else if (value === "270") { currentMode = "chaos270";
      } else if (value === "the_prison_that_holds_god") { currentMode = "prison";
      } else if (value === "simple") { currentMode = "simple";
      }
    });
  });
}
window.draw = function() {
  window.background(30);
  window.orbitControl();
  system.render(currentMode, 1.5, 1, 8);
}




/* DOES NOT REALLY FIT IN  BUT COOL
  for (let [axis, value] of rotations) {
  this.applyRotate(axis, value, angleOffset);
}
/////////////////////////////////////////////////
applyRotatesimple(axis, value, offset) {
  if (axis === "x") rotateX(value * offset);
  if (axis === "y") rotateY(value * offset);
  if (axis === "xy") {
    const [x, y] = value;
    rotateX(x * offset);
    rotateY(y * offset);
  }
}
  */
/*
let canv = document.getElementsByClassName('canvas_ontainer')[0];
let color = [
  [255, 0, 0],    // Red
  [0, 255, 0],    // Green
  [0, 0, 255],    // Blue
  [255, 255, 0],  // Yellow
  [255, 0, 255],  // Magenta
  [0, 255, 255],  // Cyan
  [255, 165, 0],  // Orange
  [128, 0, 128]   // Purple
  
];
let currentMode = 5; // 1: advance, 2: 270, 3: prison
addEventListener("DOMContentLoaded", function() {
    // Set default mode to "freeze"
    document.getElementById("simple").checked = true;
});
function setup() {
  createCanvas(1200, 700, WEBGL,canv);

noFill(); 
  // Add event listener once in setup
  document.getElementsByClassName("torus")[0].addEventListener("change", function() {
        let value = document.querySelector('input[name="canvas"]:checked').value;
        if (value === "advance") {
            currentMode = 1;
        } else if (value === "270") {
            currentMode = 2;
        } else if (value === "the_prison_that_holds_god") {
            currentMode = 3;
            camera(0, 0, 500, 0, 0, 0, 0, 1, 0);
        } else if (value === "freeze") {
            currentMode = 4;
        }else if (value === "simple") {
            currentMode = 5;
        } else {
            console.log("Unknown canvas type: " + value);
        }
  });
}

function draw() {
  background(30);
  orbitControl();
  run_input(currentMode);
}

function run_input(input){
   switch(input){
    case 1:
        chaosadvance(1.5, 1, 8);
        break;    
    case 2:
        chaos270(1.5, 1, 8);
          
        break;
    case 3:
        the_prison_that_holds_god(1.5, 1, 8);
        break;
    case 4:
        chaoscube(70);
        break;    
    case 5:
        simple(1.5, 1, 8);
          
        break;
   } 
}

function chaos270(scaleFactor, angleOffset, diameter){

  chaoscube(70);

  let angles = [0, 90, 180, 270, 360];
  let index = 0;

  for (let x of angles){
    for (let y of angles){
      for (let z of angles){

        push();
        

        scale(scaleFactor + index * 0.5);

        rotateX(x * angleOffset);
        rotateY(y * angleOffset);
        rotateZ(z * angleOffset);

        frameRotate();
        torus(80, diameter);

        pop();

        index++;
      }
    }
  }
}
function the_prison_that_holds_god(scaleFactor, angleOffset, diameter){
  chaoscube(70);

  let angles = [0, 10, 20, 30, 40, 50, 60];

  for (let x of angles){
    for (let y of angles){
      for (let z of angles){

        push();        

        rotateX(x * angleOffset);
        rotateY(y * angleOffset);
        rotateZ(z * angleOffset);

        frameRotate();
        torus(80, diameter);

        pop();
      }
    }
  }
}
function chaosadvance(scaleFactor, angleOffset, diameter){
  chaoscube(70);
  
  const rotations = [
    ["y",180],["x",180],["y",90],["x",90],
    ["xy",[180,180]],
    ["xy",[90,90]],
    ["xy",[90,180]],
    ["xy",[180,90]],
    ["z",90],["z",180],
    ["zy",[90,90]],
    ["zy",[90,180]],
    ["zy",[180,90]],
    ["zy",[180,180]],
    ["zx",[180,90]],
    ["zx",[90,90]],
    ["zx",[180,180]],
    ["zx",[90,180]],
    ["xyz",[90,90,90]],
    ["xyz",[180,180,180]],
    ["xyz",[90,180,90]],
    ["xyz",[180,90,180]],
    ["xyz",[180,90,90]],
    ["xyz",[90,180,180]],
    ["xyz",[90,90,180]],
    ["xyz",[180,180,90]],
    ];

  for(let i = 0; i < rotations.length; i++){
    push();
     

    scale(scaleFactor + i * 0.5);

    let r = rotations[i];

    if(r[0] === "x") rotateX(r[1] * angleOffset);
    if(r[0] === "y") rotateY(r[1] * angleOffset);
    if(r[0] === "z") rotateZ(r[1] * angleOffset);

    if(r[0] === "xy"){
      rotateX(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
    }

    if(r[0] === "zy"){
      rotateZ(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
    }

    if(r[0] === "zx"){
      rotateZ(r[1][0] * angleOffset);
      rotateX(r[1][1] * angleOffset);
    }

    if(r[0] === "xyz"){
      rotateX(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
      rotateZ(r[1][2] * angleOffset);
    }

    frameRotate();
    torus(80, diameter);

    pop();
  }

}
function simple(scaleFactor, angleOffset, diameter){
  chaoscube(70);
  
  const rotations = [
    ["y",180],["x",180],["y",90],["x",90],
    ["xy",[180,180]],
    ["xy",[90,90]],
    ["xy",[90,180]],
    ["xy",[180,90]],
    
    ];

  for(let i = 0; i < rotations.length; i++){
    push();
     

    scale(scaleFactor + i * 0.5);

    let r = rotations[i];

    if(r[0] === "x") rotateX(r[1] * angleOffset);
    if(r[0] === "y") rotateY(r[1] * angleOffset);
    if(r[0] === "z") rotateZ(r[1] * angleOffset);

    if(r[0] === "xy"){
      rotateX(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
    }

    if(r[0] === "zy"){
      rotateZ(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
    }

    if(r[0] === "zx"){
      rotateZ(r[1][0] * angleOffset);
      rotateX(r[1][1] * angleOffset);
    }

    if(r[0] === "xyz"){
      rotateX(r[1][0] * angleOffset);
      rotateY(r[1][1] * angleOffset);
      rotateZ(r[1][2] * angleOffset);
    }

    frameRotate();
    torus(80, diameter);

    pop();
  }

 
}
function chaoscube(scaleFactor){
  push();
  translate(0, 0, 0);
  box(scaleFactor);  
  pop();
}
function frameRotate() {
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
}

noFill();
stroke(255);

*/