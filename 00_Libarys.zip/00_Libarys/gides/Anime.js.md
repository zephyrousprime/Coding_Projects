---
tags:
  - library/javascript
  - category/animation
  - anime.js
aliases:
  - Anime.js
---

# Anime.js

> Animation library

## Related Libraries
- [[GSAP]]

## Parent Indexes
- [[Libary-Master]]
- [[Category-Index]]

## Backlinks
- [[Libary-Master]]

## Notes

Add installation instructions, examples, gotchas, and patterns here.

## Navigation
- [[Libary-Master]]
