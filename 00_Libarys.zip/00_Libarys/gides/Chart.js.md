---
tags:
  - library/javascript
  - category/charts
  - chart.js
aliases:
  - Chart.js
---

# Chart.js

> Charting library

## Related Libraries
- [[ApexCharts]]
- [[D3.js]]

## Parent Indexes
- [[Libary-Master]]
- [[Category-Index]]

## Backlinks
- [[Libary-Master]]

## Notes

Add installation instructions, examples, gotchas, and patterns here.

## Navigation
- [[Libary-Master]]
