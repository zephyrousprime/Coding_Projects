---
tags:
  - library/javascript
  - category/tables
  - tabulator
aliases:
  - Tabulator
---

# Tabulator

> Interactive data tables

## Related Libraries
- [[Chart.js]]
- [[ApexCharts]]

## Parent Indexes
- [[Libary-Master]]
- [[Category-Index]]

## Backlinks
- [[Libary-Master]]

## Notes

Add installation instructions, examples, gotchas, and patterns here.

## Navigation
- [[Libary-Master]]
