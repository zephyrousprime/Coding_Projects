---
tags:
  - library/javascript
  - category/charts
  - apexcharts
aliases:
  - ApexCharts
---

# ApexCharts

> Interactive charts

## Related Libraries
- [[Chart.js]]

## Parent Indexes
- [[Libary-Master]]
- [[Category-Index]]

## Backlinks
- [[Libary-Master]]

## Notes

Add installation instructions, examples, gotchas, and patterns here.

## Navigation
- [[Libary-Master]]
