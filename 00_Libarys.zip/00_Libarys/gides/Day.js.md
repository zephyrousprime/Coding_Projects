---
tags:
  - library/javascript
  - category/dates
  - day.js
aliases:
  - Day.js
---

# Day.js

> Date handling

## Related Libraries
- [[Lodash]]

## Parent Indexes
- [[Libary-Master]]
- [[Category-Index]]

## Backlinks
- [[Libary-Master]]

## Notes

Add installation instructions, examples, gotchas, and patterns here.

## Navigation
- [[Libary-Master]]
