(function () {
    const controls = document.getElementById('rps-controls');
    const feedback = document.getElementById('rps-feedback');
    const resetBtn = document.getElementById('rps-reset');
    const playerScoreElem = document.getElementById('rps-player-score');
    const computerScoreElem = document.getElementById('rps-computer-score');
    const options = ['Rock', 'Paper', 'Scissors'];
    let playerScore = 0;
    let computerScore = 0;
    let bob = true;
    let stop = false;
    addEventListener('load', () => {
        playerScoreElem.textContent = playerScore;
        computerScoreElem.textContent = computerScore;
    })
    function playRound(userChoice) {
        if (stop === true) return;
        const computerChoice = options[Math.floor(Math.random() * options.length)];
        let result;
        if (userChoice === computerChoice) result = "It's a tie!";
        else if (
            (userChoice === 'Rock' && computerChoice === 'Scissors') ||
            (userChoice === 'Paper' && computerChoice === 'Rock') ||
            (userChoice === 'Scissors' && computerChoice === 'Paper')
        ) result = 'You win!'; 
        else result = 'You lose!';
        feedback.textContent = `You chose ${userChoice}, computer chose ${computerChoice}. ${result}`;
        bob = false;
        updatescore(result);
        bob = true;
        setTimeout(() => { feedback.textContent = 'Select a option to try again';  }, 2500);
    }
    function updatescore(outcome) {
        if (playerScore + computerScore === 5) {
            if (playerScore > computerScore) {
                feedback.textContent = `Game over! You won the game ${playerScore} to ${computerScore}. Click reset to play again.`;
            }
            else if (computerScore > playerScore) {
                feedback.textContent = `Game over! You lost the game ${playerScore} to ${computerScore}. Click reset to play again.`;
            }
            else {
                feedback.textContent = `Game over! It's a tie ${playerScore} to ${computerScore}. Click reset to play again.`;
            }
            bob = false;
            stop = true
        }
        if (outcome === 'You win!'){
            playerScore++;
            console.log(playerScore);
            playerScoreElem.textContent = playerScore;
        }
        else if (outcome === 'You lose!'){
            computerScore++;
            computerScoreElem.textContent = computerScore;
        }
        else if (outcome === "It's a tie!"){
            // No score change on tie
        }
        return;
    }
    controls.addEventListener('click', (e) => {
        if (!bob) return;
        const choice = e.target.getAttribute('data-choice');
        if (choice) playRound(choice);
    });

    resetBtn.addEventListener('click', () => {
        feedback.textContent = 'Select a option';
        playerScore = 0;
        computerScore = 0;
        playerScoreElem.textContent = playerScore;
        computerScoreElem.textContent = computerScore;
        stop = false;
        bob = true;
    });
})();
