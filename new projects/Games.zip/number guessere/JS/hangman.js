(function () {
// varibels
    // declared varibles
    const wordDisplay = document.getElementById('hangman-word');
    const messageEl = document.getElementById('hangman-msg');
    const guessedEl = document.getElementById('hangman-guessed');
    const attemptsEl = document.getElementById('hangman-attempts');
    const inputbob = document.getElementById('hangman-input');
    const guessBtn = document.getElementById('hangman-guess-btn');
    const resetBtn = document.getElementById('hangman-reset-btn');
    const hangmancategory = document.getElementById('hangman-category');
    // declares changeable declarations
    // sets the array to hold words fetched from the JSON file
    let word = '';
    let words = [];
    let guessedLetters = [];
    let wrongAttempts = 0;
    const maxAttempts = 7;
// functions
    // pick a random word from the words array. have the return so it will return the chosen word 
    function pickWord() { return words[Math.floor(Math.random() * words.length)]; }
    // create the masked word with underscores for unguessed letters
    function maskedWord() { return word.split('').map(ch => (guessedLetters.includes(ch) ? ch : '_')).join(' '); }
    // update the displayed word, guessed letters, and number of wrong attempts
    async function updateDisplay() {
        //seting worddisplay text content to the masked word with guessed letters revealed
        wordDisplay.textContent = maskedWord();
        // updateds displayed guessed letters and attempts
        guessedEl.textContent = 'Guessed: ' + (guessedLetters.length ? guessedLetters.join(', ') : 'none');
        attemptsEl.textContent = `Wrong attempts: ${wrongAttempts} / ${maxAttempts}`;
        
        // Draw hangman based on wrong attempts
        await drawHangman(wrongAttempts);
    }
    // set message function to display messages to the user and color them based on error or success
    function setMessage(msg, isError) {
        // set the message text and color based on error or success
        messageEl.textContent = msg;
        // set the message color based on whether it's an error or not
        messageEl.style.color = isError ? 'darkred' : 'green';
    }   
    // check if the player has won by verifying if all letters have been guessed
    function hasWon() {
     // check if every character in the word has been guessed
    return word.split('').every(ch => guessedLetters.includes(ch));
    }

    // check for win or lose conditions by checking if there are any underscores left or if max attempts have been reached and returning true or false
    function checkWinLose() {
        // check win condition by calling hasWon function
        if (hasWon()) {
            //run the function setmessage with the winnning word
            setMessage(`You won! The word was "${word}".`);
            // disable input and guess button
            inputbob.disabled = true;
            guessBtn.disabled = true;
            // return true if won and stops the functon from continuing
            return Promise.resolve(true);
        }
        // check lose condition by comparing wrong attempts to max attempts
        if (wrongAttempts >= maxAttempts) {
            setMessage(`You lost. The word was "${word}".`, true);
            // disable input and guess button
            inputbob.disabled = true; guessBtn.disabled = true;
            // return true if won and stops the functon from continuing
            return Promise.resolve(true);
        }
            // return False if won and stops the functon from continuing
        return Promise.resolve(false);
    }
    // draw the hangman figure based on the number of wrong attempts
    async function drawHangman(stage) {
    // a switch statement to draw each part of the hangman based on the current stage like a bunch of if staments
    switch(stage) {
        //runs multiple cases to check each stage and update the image accuritly
        case 1: // gallows
            document.getElementById('hangmanImages').src = "../Images/2.png";
            break;
        case 2: // pole
            document.getElementById('hangmanImages').src = "../Images/3.png";
            break;
        case 3: // top beam
            document.getElementById('hangmanImages').src = "../Images/4.png";
            break;
        case 4: // rope
            document.getElementById('hangmanImages').src = "../Images/5.png";;
            break;
        case 5: // head
            document.getElementById('hangmanImages').src = "../Images/6.png";
            break;
        case 6: // body
            document.getElementById('hangmanImages').src = "../Images/7.png";
            break;
        case 7: // arms
            document.getElementById('hangmanImages').src = "../Images/8.png";
            break;
        default:   
            document.getElementById('hangmanImages').src = "../Images/1.png";
            break;
    }
    // Return a resolved promise after updating the image
    // proble not needed but it looks cool
    return Promise.resolve(); // Move OUTSIDE the switch
}

    // handle the user's guess, updating state and display accordingly with async and await to ensure proper sequence
    async function handleGuess(letter) {
        // checks for validate input
        if (!letter || !/^[a-z]$/.test(letter)) {
            setMessage('Please enter a single letter (a-z).', true); return;
        }
        // check if letter was already guessed
        if (guessedLetters.includes(letter)) {
            setMessage(`You already guessed "${letter}".`, true); return;
        }
        // process the guess
        guessedLetters.push(letter);
        // check if the guessed letter is in the word and sending a corosponding respose message 
        if (word.includes(letter)) setMessage(`Good guess: "${letter}"`);
        else { wrongAttempts++; setMessage(`Wrong guess: "${letter}"`, true); }
        // update the display and check for win/lose conditions
        await updateDisplay(); await checkWinLose();
    }
    // reset the game state for a new game
    async function resetGame() {
        // pick a new word and reset variables
        // await to ensure the word is picked before proceeding
        word = pickWord(); // Store the result in 'word' variable
        guessedLetters = [];
        wrongAttempts = 0;
        inputbob.value = '';
        inputbob.disabled = false; guessBtn.disabled = false;
        setMessage('New game started. Good luck!');
        await updateDisplay();
    }
    // event listeners for guess button, enter key, and reset button
    guessBtn.addEventListener('click', async () => {
        // trims and lower cases the input before handing the guess
        const val = inputbob.value.trim().toLowerCase();
        // handels the guess and awaits for a input
        await handleGuess(val);
        inputbob.value = ''; inputbob.focus();
    });
    // handle enter key press to trigger guess with event listerners
    inputbob.addEventListener('keydown', (e) => { if (e.key === 'Enter') guessBtn.click(); });
    resetBtn.addEventListener('click', resetGame);

    // event listener for category change
    hangmancategory.addEventListener('change', async () => {
        // set the category to the users selected option then fetchs the json file with matching name
        const category = hangmancategory.value;
        await fetch(`../JS/${category}.json`) 
        // load and parse the JSON file
        .then(res => res.json())
        .then(data => { words = data; })
        .catch(err => console.error('Failed to load category:', err));
        await resetGame();
    });
    addEventListener('load', async () => {
    // fetch words from external JSON file
    await fetch("../JS/words.json")  // Changed from "words.json"
    // load and parse the JSON file
    .then(res => res.json())
    // store the words in the words array and start the game
    .then(data => {
        words = data;
        // start game AFTER words are loaded
        resetGame(); 
    })
     // Add error handling
    .catch(err => console.error('Failed to load words:', err));
});

})();
