(function () {
    const cells = Array.from(document.querySelectorAll('.ttt-cell'));
    const statusEl = document.getElementById('ttt-status');
    const resetBtn = document.getElementById('ttt-reset');
    const modeToggle = document.getElementById('ttt-mode-toggle');

    let board = Array(9).fill('');
    let currentPlayer = 'X';
    let gameOver = false;
    let twoPlayerMode = false;

    const wins = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ];

    function render() {
        cells.forEach((cell, i) => cell.textContent = board[i]);
        statusEl.textContent = gameOver ? 'Game over' : `Current: ${currentPlayer}`;
    }

    function checkWin() {
        for (const [a,b,c] of wins) {
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                return board[a];
            }
        }
        if (board.every(Boolean)) return 'tie';
        return null;
    }

    function makeMove(i) {
        if (gameOver || board[i]) return;
        board[i] = currentPlayer;
        const result = checkWin();
        if (result === 'tie') {
            statusEl.textContent = "It's a tie!";
            gameOver = true;
        } else if (result) {
            statusEl.textContent = `${result} wins!`;
            gameOver = true;
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            statusEl.textContent = `Current: ${currentPlayer}`;
        }
        render();
    }

    function availableMoves() {
        return board.map((v, i) => v === '' ? i : null).filter(v => v !== null);
    }

    function aiMove() {
        if (gameOver) return;
        const avail = availableMoves();
        if (!avail.length) return;
        const choice = avail[Math.floor(Math.random() * avail.length)];
        makeMove(choice);
    }

    cells.forEach((cell, idx) => {
        cell.addEventListener('click', () => {
            if (gameOver || board[idx]) return;
            makeMove(idx);
            if (!twoPlayerMode && !gameOver && currentPlayer === 'O') {
                setTimeout(aiMove, 350);
            }
        });
    });

    resetBtn.addEventListener('click', () => {
        board = Array(9).fill('');
        currentPlayer = 'X';
        gameOver = false;
        render();
    });

    modeToggle.addEventListener('change', () => {
        twoPlayerMode = !!modeToggle.checked;
        statusEl.textContent = twoPlayerMode ? '2 Player Mode: ON' : '2 Player Mode: OFF';
        if (!twoPlayerMode && !gameOver && currentPlayer === 'O') setTimeout(aiMove, 300);
    });

    render();
})();
